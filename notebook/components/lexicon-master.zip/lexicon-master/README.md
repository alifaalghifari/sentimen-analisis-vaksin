Lexicon
======
Data Bahasa Indonesia


1. Kata dasar KBBI
Kata dasar beserta jenisnya dalam Kamus Besar Bahasa Indonesia


